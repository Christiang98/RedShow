"use client"

import type React from "react"
import { useRouter } from "next/navigation"
import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { loginUser } from "@/lib/auth"

export function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      const result = await loginUser(email, password)
      console.log("[v0] Login con:", { email, password })

      if (result.success) {
        console.log("[v0] Login exitoso:", result.user)
        // Redirigir al dashboard basado en rol
        if (result.user?.role === "owner") {
          router.push("/profile/owner")
        } else if (result.user?.role === "artist") {
          router.push("/profile/artist")
        } else {
          router.push("/search")
        }
      } else {
        setError(result.message)
      }
    } catch (err) {
      setError("Error al iniciar sesión. Intenta de nuevo.")
      console.log("[v0] Error en login:", err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md p-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-primary mb-2">Red Show</h1>
          <p className="text-muted-foreground">Inicia sesión en tu cuenta</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="p-3 bg-destructive/10 border border-destructive rounded-lg text-destructive text-sm">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Email</label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="tu@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Contraseña</label>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
            disabled={loading}
          >
            {loading ? "Iniciando sesión..." : "Iniciar Sesión"}
          </Button>
        </form>

        <div className="mt-6 text-center text-sm text-muted-foreground space-y-2">
          <p>
            ¿No tienes cuenta?{" "}
            <Link href="/register" className="text-secondary hover:underline font-semibold">
              Regístrate aquí
            </Link>
          </p>
          <p>
            <Link href="#" className="text-secondary hover:underline">
              ¿Olvidaste tu contraseña?
            </Link>
          </p>
        </div>
      </Card>
    </div>
  )
}
