"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getCurrentUser, logoutUser } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function DashboardPage() {
  const [user, setUser] = useState(null)
  const router = useRouter()

  useEffect(() => {
    const currentUser = getCurrentUser()
    if (!currentUser) {
      router.push("/login")
    } else {
      setUser(currentUser)
    }
  }, [router])

  const handleLogout = () => {
    logoutUser()
    router.push("/login")
  }

  if (!user) {
    return <div className="flex items-center justify-center min-h-screen">Cargando...</div>
  }

  return (
    <div className="min-h-screen bg-background">
      <nav className="bg-primary text-primary-foreground p-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">Red Show</h1>
          <div className="flex gap-4">
            <Link href="/search">
              <Button variant="ghost" className="text-primary-foreground hover:bg-primary/80">
                Buscar
              </Button>
            </Link>
            <Link href="/bookings">
              <Button variant="ghost" className="text-primary-foreground hover:bg-primary/80">
                Contrataciones
              </Button>
            </Link>
            <Link href="/messaging">
              <Button variant="ghost" className="text-primary-foreground hover:bg-primary/80">
                Mensajes
              </Button>
            </Link>
            <Button onClick={handleLogout} variant="destructive">
              Logout
            </Button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto p-8">
        <div className="bg-card rounded-lg p-8 border border-border">
          <h2 className="text-3xl font-bold text-primary mb-4">Bienvenido, {user.username}!</h2>
          <p className="text-muted-foreground mb-6">Rol: {user.role}</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link href="/profile/owner" className="p-4 bg-primary/10 rounded-lg hover:bg-primary/20 transition">
              <h3 className="font-semibold text-primary">Mi Perfil</h3>
              <p className="text-sm text-muted-foreground">Ver y editar información</p>
            </Link>
            <Link href="/search" className="p-4 bg-secondary/10 rounded-lg hover:bg-secondary/20 transition">
              <h3 className="font-semibold text-secondary">Explorar</h3>
              <p className="text-sm text-muted-foreground">Buscar espacios y servicios</p>
            </Link>
            <Link href="/bookings" className="p-4 bg-accent/10 rounded-lg hover:bg-accent/20 transition">
              <h3 className="font-semibold text-accent">Contrataciones</h3>
              <p className="text-sm text-muted-foreground">Gestionar solicitudes</p>
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
