export interface User {
  id: string
  username: string
  email: string
  role: "owner" | "artist" | "organizer"
  phone: string
  dni: string
  city: string
  province: string
  neighborhood: string
  instagram?: string
  tiktok?: string
  createdAt: string
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
}

const USERS_STORAGE_KEY = "redshow_users"
const AUTH_STORAGE_KEY = "redshow_auth"

export function registerUser(userData: Omit<User, "id" | "createdAt"> & { password: string }): {
  success: boolean
  message: string
} {
  const users = getAllUsers()

  // Verificar si el email ya existe
  if (users.some((u) => u.email === userData.email)) {
    return { success: false, message: "El email ya está registrado" }
  }

  // Crear nuevo usuario
  const newUser: User = {
    ...userData,
    id: Math.random().toString(36).substr(2, 9),
    createdAt: new Date().toISOString(),
  }

  // Guardar usuario
  users.push({ ...newUser, password: hashPassword(userData.password) })
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users))

  return { success: true, message: "Registro exitoso" }
}

export function loginUser(email: string, password: string): { success: boolean; user: User | null; message: string } {
  const users = getAllUsers()
  const user = users.find((u) => u.email === email)

  if (!user) {
    return { success: false, user: null, message: "Email no encontrado" }
  }

  const storedUser = user as User & { password: string }
  if (storedUser.password !== hashPassword(password)) {
    return { success: false, user: null, message: "Contraseña incorrecta" }
  }

  // Guardar sesión
  const { password: _, ...userWithoutPassword } = storedUser
  localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(userWithoutPassword))

  return { success: true, user: userWithoutPassword, message: "Login exitoso" }
}

export function logoutUser() {
  localStorage.removeItem(AUTH_STORAGE_KEY)
}

export function getCurrentUser(): User | null {
  const auth = localStorage.getItem(AUTH_STORAGE_KEY)
  return auth ? JSON.parse(auth) : null
}

export function isUserAuthenticated(): boolean {
  return getCurrentUser() !== null
}

export function getAllUsers(): Array<User & { password: string }> {
  const users = localStorage.getItem(USERS_STORAGE_KEY)
  return users ? JSON.parse(users) : []
}

// Simple hash para demo (en producción usar bcrypt)
function hashPassword(password: string): string {
  return Buffer.from(password).toString("base64")
}
